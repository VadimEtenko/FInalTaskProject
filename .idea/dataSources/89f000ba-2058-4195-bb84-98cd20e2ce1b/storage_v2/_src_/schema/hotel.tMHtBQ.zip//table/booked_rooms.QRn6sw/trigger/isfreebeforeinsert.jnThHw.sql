create definer = root@localhost trigger isFreeBeforeInsert
    before insert
    on booked_rooms
    for each row
BEGIN
	  IF (NEW.status_id = 0) THEN
		SET NEW.status_id = NULL;
	  END IF;	  
    END;

