create definer = root@localhost event delete_unpaied_booking_TEST on schedule
    every '30' SECOND
        starts '2021-06-22 17:10:03'
    on completion preserve
    disable
    do
    DELETE FROM booked_rooms 
	WHERE 
		is_paied != TRUE;

