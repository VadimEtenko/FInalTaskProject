create definer = root@localhost event delete_unpaied_booking on schedule
    at '2021-06-17 00:00:00'
    on completion preserve
    disable
    do
    DELETE FROM booked_rooms 
	WHERE 
		DATEDIFF(CURRENT_DATE, booked_rooms.time_creating) > 2
	AND
		is_paied != true;

